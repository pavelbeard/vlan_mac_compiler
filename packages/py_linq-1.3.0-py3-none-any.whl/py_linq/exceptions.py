class NoElementsError(Exception):
    pass


class NullArgumentError(Exception):
    pass


class NoMatchingElement(Exception):
    pass


class MoreThanOneMatchingElement(Exception):
    pass
